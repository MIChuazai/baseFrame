/*
Navicat MySQL Data Transfer

Source Server         : 123
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : app

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2018-08-14 15:55:34
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for card
-- ----------------------------
DROP TABLE IF EXISTS `card`;
CREATE TABLE `card` (
  `id` varchar(64) NOT NULL,
  `userID` varchar(64) NOT NULL,
  `IDPath` varchar(255) NOT NULL,
  `createTime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of card
-- ----------------------------

-- ----------------------------
-- Table structure for member
-- ----------------------------
DROP TABLE IF EXISTS `member`;
CREATE TABLE `member` (
  `id` varchar(64) NOT NULL,
  `name` varchar(50) NOT NULL,
  `sex` tinyint(3) unsigned DEFAULT NULL COMMENT '1.男 2.女',
  `tel` varchar(20) NOT NULL COMMENT '手机号码',
  `payName` varchar(255) NOT NULL COMMENT '支付宝账号',
  `telRecord` text NOT NULL COMMENT '通话记录',
  `status` tinyint(3) unsigned NOT NULL COMMENT '0.未通过 1.通过',
  `createTime` int(11) NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of member
-- ----------------------------
INSERT INTO `member` VALUES ('asd', 'jack', '1', '13562544562', 'dshdfkh', '123461321,465613132,5464684,', '0', '1534122782');
INSERT INTO `member` VALUES ('qwe', 'jim', '2', '13652645864', 'zhifubao', '1235611234684651,546,', '0', '1534122892');

-- ----------------------------
-- Table structure for paypic
-- ----------------------------
DROP TABLE IF EXISTS `paypic`;
CREATE TABLE `paypic` (
  `id` varchar(64) NOT NULL,
  `memeberID` varchar(64) NOT NULL,
  `payPic` varchar(255) NOT NULL,
  `createTime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of paypic
-- ----------------------------

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` varchar(64) NOT NULL,
  `nickName` varchar(20) NOT NULL COMMENT '登录账户',
  `userName` varchar(20) NOT NULL COMMENT '真实姓名',
  `password` varchar(120) NOT NULL COMMENT '密码',
  `sex` tinyint(3) unsigned DEFAULT NULL COMMENT '性别 1.男 2.女',
  `role` tinyint(3) unsigned NOT NULL,
  `phone` varchar(20) NOT NULL COMMENT '手机号码',
  `status` tinyint(3) unsigned NOT NULL COMMENT '状态 1.启用 2.禁用 ',
  `salt` varchar(6) NOT NULL COMMENT '盐参数',
  `create_time` int(11) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(11) unsigned DEFAULT NULL,
  `delete_time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('f4b41f6b-7167-6ae3-7118-3bb51154b007', 'appAdminRoot', '普通用户', '29c50089b77ec6b51bf85d1c4cbbebb9', '2', '0', '13656235894', '0', '2zLb8T', '1534224095', null, null);
INSERT INTO `user` VALUES ('f9c630cf-6ccd-1d1d-3ffa-70e00c888044', 'user123456', '管理员', '84ac18d52c63a0b837c66cdb3d9081ed', '1', '2', '13656235896', '1', 'n9mYAE', '1534231458', null, null);
INSERT INTO `user` VALUES ('1e0dba2f-83d0-549c-ea9f-fdcb3e21fd57', 'adminRoot', '超级管理员', '8b720dc11c60a870f44d0c2155a18333', '1', '1', '13962354568', '1', 'am9PMq', '1534224969', null, null);
INSERT INTO `user` VALUES ('463bb523-784f-83c3-98d0-55932edae380', 'user123', '普通用户2', 'a3159a0ab43950dae95c40076ce629d0', '2', '2', '13696525698', '2', '2finrc', '1534227596', null, null);
