<?php
/**
 * Created by PhpStorm.
 * Creator: HuaZai
 * Date: 2018/7/10
 * Time: 10:56
 */
namespace app\admin\controller;
use think\Request;
use think\Db;
use app\admin\model\User as Usr;
use think\Session;
class user extends Common
{

/*********************************会员数据处理开始*****************************************************/
    //会员列表
    public function memberLst(){

        return view();
    }

    //添加会员页面
    public function memberAdd(){
        return view();
    }


    //会员编辑
    public function memberUpd(){
        return view();
    }

    /**新增会员
     * @param Request $request
     */
    public function member_add(Request $request){

    }

    /**会员编辑
     * @param Request $request
     */
    public function member_upd(Request $request){

    }

    /**会员删除
     * @param Request $request
     */
    public function member_del(Request $request){

    }

    /**会员的启用禁用
     * @param Request $request
     */
    public function memberStatus(Request $request){
        if($request->isPost() && input('post.id')){
            $id = input('post.id');
            $status = input('post.status');
            $model = new Member;

            $res = $model->memberStatus($id, $status);
            echo json_encode($res);exit();
        }else{
            $res = [
                'code'=>2,
                'msg'=>'网络繁忙,请稍后再试!'
            ];
            echo json_encode($res);exit();
        }
    }

 /**************************************会员数据处理结束**************************************************************/

 /**************************************管理员数据处理开始*************************************************************/
    //管理员列表
    public function mangerLst(){
        $model = new Usr;
        $data = $model->where('status','<',3)->where('role','>',1)->select();
        return view('user/manger_lst',compact('data'));
    }

    //管理员添加
    public function mangerAdd(Request $request){
        if($request->isPost()){
            $model = new Usr;
            $allData = input('post.userData');
            $arr = parse_str($allData,$userData);

            $res = $model->userAdd($userData);
            echo json_encode($res);exit;
        }else{
            $res = [
                'code'=>2,
                'msg'=>'网络繁忙，请稍后再试！'
            ];
            echo json_encode($res);exit;
        }
    }

    //管理员编辑
    public function mangerUpd(Request $request){
        if($request->isPost()){
            $data = input('post.userData');
            $id = input('post.id');
            $arr = parse_str($data,$userData);
            $userData['id'] = $id;

            $model = new Usr;
            $res = $model->userUpd($userData);
            echo json_encode($res);exit;
        }else{
            $res = [
                'code'=>2,
                'msg'=>'网络繁忙,请稍后再试！'
            ];
            echo json_encode($res);exit;
        }
    }

    /**新增管理员
     * @param Request $request
     */
    public function manger_add(){
        return view();
    }

    /**管理员编辑
     * @param Request $request
     */
    public function manger_upd(){
        $id = input('get.id');

        $model = new Usr;
        $data = $model->find($id);

        return view('user/manger_upd',compact('data'));
    }

    /**管理员的启用禁用
     * @param Request $request
     */
    public function userStatus(Request $request){
        if($request->isPost() && input('post.id')){
            $id = input('post.id');
            $status = intval(input('post.status'));
            $model = new Usr;

            $res = $model->userStatus($id, $status);
            echo json_encode($res);exit();
        }else{
            $res = [
                'code'=>2,
                'msg'=>'网络繁忙,请稍后再试!'
            ];
            echo json_encode($res);exit();
        }
    }

    /**管理员删除
     * @param Request $request
     */
    public function user_del(Request $request){
        if($request->isPost() && input('post.id')){
            $model = new Usr;
            $id = input('post.id');

            $res = $model->userDel($id);
            echo json_encode($res);exit;
        }else{
            $res = [
                'code'=>2,
                'msg'=>'网络繁忙，请稍后再试！'
            ];
            echo json_encode($res);exit;
        }
    }




 /**************************************管理员数据处理结束*************************************************************/

    /**数据唯一性验证
     * @param Request $request
     * @return string
     */
    public function data_unique(Request $request){
        $name = input('post.name');
        $valData = input('post.val');
        $model = new Usr;
        if($name == 'nickName'){
            $res = $model->where('nickName','=',$valData)->find();
            $res != ''?$arr= "用户名已存在！":$arr = "true";
            return $arr;exit();
        }
        if($name == 'phone'){
            $res = $model->where('phone','=',$valData)->find();
            $res != ''?$arr= "手机号已存在！":$arr = "true";
            return $arr;exit();
        }
    }



}
