<?php
/**
 * Created by PhpStorm.
 * Creator: HuaZai
 * Date: 2018/7/10
 * Time: 10:52
 */
namespace app\admin\controller;

class Index extends Common
{
    public function index(){
        //后台首页
        return view();
    }

    public function welcome(){
        return view();
    }




}
