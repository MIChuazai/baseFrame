<?php
namespace app\admin\controller;
use think\Controller;
use think\Request;
use think\Validate;
class Common extends Controller
{
      use \traits\controller\Jump;//类里面引入jump类
     function checkUser(){

     //判断用户是否已经登录
     \think\Hook::listen('CheckAuth',$userInfo);
    }
    protected $beforeActionList = [
        "checkUser",
    ];
   
    
    //封装无限级分类函数
    public function getTrees($data,$pid=0,$level=0){
        //定义一个静态的数组,后面递归调用自身,此数组只初始一次
        static $lists = [];
        foreach($data as $k=>$v){
            if($v['pid']==$pid){//找到顶级 pid=0;
                $v['level']=$level;//给数组添加level元素
                $lists[]=$v; //将结果放入$lists
                $this->getTrees($data,$v['id'],$level+1);//递归调用本身
            }
        }
        //返回数据
        return $lists;
    }

}