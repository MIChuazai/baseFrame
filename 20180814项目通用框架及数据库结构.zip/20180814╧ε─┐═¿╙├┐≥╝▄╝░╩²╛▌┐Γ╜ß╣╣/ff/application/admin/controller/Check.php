<?php
/**
 * Created by PhpStorm.
 * Creator: HuaZai
 * Date: 2018/7/10
 * Time: 10:55
 */
namespace app\admin\controller;

use think\Db;
//use app\admin\model\User;
class Check extends Common
{
    //待审核列表
    public function prePass(){
        return view();
    }

    //已审核列表
    public function endPass(){
        return view();
    }


}
