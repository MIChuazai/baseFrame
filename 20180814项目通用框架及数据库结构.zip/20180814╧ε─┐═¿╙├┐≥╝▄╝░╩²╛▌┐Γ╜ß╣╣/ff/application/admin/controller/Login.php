<?php
/**
 * Created by PhpStorm.
 * Creator: HuaZai
 * Date: 2018/7/10
 * Time: 10:51
 */
namespace app\admin\controller;
use think\Controller;
use think\Request;
use think\Validate;
use think\Db;
use app\admin\model\User;
use think\Session;
class Login extends Controller
{
    /**后台登录页
     * @return \think\response\View
     */
    public function login(){
        return view();
    }

    /**登录信息验证
     * @param Request $request
     */
    public function checkLogin(Request $request){
        //判断是否是POST方式提交
        if ($request->isPost()){
            $res = parse_str(input('post.data'),$data);
            $model = new User;
            //验证用户名和密码
            $userInfo = $model->field('id,nickName,userName,password,sex,role,phone,status,salt')->where('nickName','=',$data['nickName'])->find();
            if ($userInfo){
                $salt = $userInfo['salt'];
                $pass = md5($data['password'].$salt);
                //若账户存在,判断密码是否正确
                if ($userInfo['password'] === $pass){
                    //验证账号是否禁用
                    if($userInfo['status'] == 2){
                        $resData = [
                            'code' => 2,
                            'msg'  => '登录账号已被禁用,请联系管理员！'
                        ];
                        echo json_encode($resData);exit();
                    }
                    //记录用户的登陆信息
                    unset($userInfo['salt']);//删除盐
                    unset($userInfo['password']);//删除密码
                    unset($userInfo['nickName']);//删除账号信息

                    Session::set('userInfo',$userInfo);
                    //更新盐参数
                    $create_result = $model->saltUpd($userInfo['id'],$data['password']);
                    if ($create_result){
                        $resData = [
                            'code' => 1,
                            'msg'  => '登录成功！'
                        ];
                    }else{
                        $resData = [
                            'code' => 2,
                            'msg'  => '网络繁忙，请重新登录！'
                        ];
                    }

                    echo json_encode($resData);exit();
                }else{
                    $resData = [
                        'code' => 2,
                        'msg'  => '帐号或密码错误！1,'.$pass.','.$userInfo['password'].','.$userInfo['id'].','.$data['password']
                    ];
                    echo json_encode($resData);exit();
                }
            }else{
                $resData = [
                    'code' => 2,
                    'msg'  => '帐号或密码错误！2'
                ];
                echo json_encode($resData);exit();
            }
        }

    }

    public function loginOut(){
        Session::delete('userInfo');
        return view('login/login');
    }

}