<?php
/**
 * Created by PhpStorm.
 * Creator: 华仔
 * Date: 2018/8/13
 * Time: 13:21
 */
namespace app\admin\model;

use think\Model;
use think\Request;
use think\Db;
use traits\model\SoftDelete;
use think\Validate;

class User extends Model{
    //设置数据表(不含表前缀)
    protected $name = 'user';
    protected $auto = ['create_time','update_time'];
    use SoftDelete;
    protected $deleteTime = 'delete_time';


    /**新增管理员
     * @param $data
     * @return array
     */
    public function userAdd($data){
        $result   = $this->data_check($data);
        if($result['code'] == 2){
            $resData = [
                'code'=>2,
                'msg'=>$result['msg']
            ];
            return $resData;exit();
        }

        $salt = $this->getrandstr();
        $data['password'] =  md5(trim($data['password']).$salt);
        $data['salt'] = $salt;
        $data['id'] = $this->createID();
        $data['create_time'] = time();
        $data['role'] = isset($data['role'])?intval($data['role']):2;

        $model = new User;
        if ($model->save($data)){
            $resData = [
                'code'=>1,
                'msg'=>'新增成功！'
            ];
            return $resData;exit();
        }else{
            $resData = [
                'code'=>2,
                'msg'=>'新增失败，请联系管理员！'
            ];
            return $resData;exit();
        }
    }


    public function userUpd($data){

        //用户名，密码，手机号码同时修改---Ok
        if($data['nickName'] != '' && $data['password'] != '' && $data['phone'] != ''){
            $result   = $this->data_check($data);
            if($result['code'] == 2){
                $resData = [
                    'code'=>2,
                    'msg'=>$result['msg']
                ];
                return $resData;exit();
            }
            $id = $data['id'];
            $salt = $this->getrandstr();
            $data['password'] =  md5($data['password'].$salt);
            $data['salt'] = $salt;
            unset($data['id']);
            $model = new User;
            $res = $model->where('id','=',$id)->update($data);
            if ($res){
                $resData = [
                    'code'=>1,
                    'msg'=>'修改成功！'
                ];
                return $resData;exit();
            }else{
                $resData = [
                    'code'=>2,
                    'msg'=>'修改失败，请联系管理员！'
                ];
                return $resData;exit();
            }
        }

        //用户名，密码，手机号都不修改时----OK
        if($data['nickName'] == '' && $data['password'] == '' && $data['phone'] == ''){
            //数据验证
            $rule =[
                'userName'  => 'require',
            ];
            $msg = [
                'userName.require'  =>'用户真实姓名必须',
            ];
            $validate = new Validate($rule,$msg);
            $result   = $validate->check($data);
            if(!$result){
                $err_msg = $validate->getError();
                $resData = [
                    'code'=>2,
                    'msg' =>$err_msg
                ];
                return $resData;exit();
            }else{
                //数据处理
                $id = $data['id'];
                unset($data['nickName']);
                unset($data['password']);
                unset($data['phone']);
                unset($data['id']);
                $model = new User;
                $res = $model->where('id','=',$id)->update($data);
                if ($res){
                    $resData = [
                        'code'=>1,
                        'msg'=>'修改成功！'
                    ];
                    return $resData;exit();
                }else{
                    $resData = [
                        'code'=>2,
                        'msg'=>'修改失败，请联系管理员！'
                    ];
                    return $resData;exit();
                }

            }
        }

        //用户名修改，密码、手机不修改-----OK
        if($data['nickName'] != '' && $data['password'] == '' && $data['phone'] == ''){
            //数据验证
            $rule =[
                'nickName'  => 'require|unique:user|min:6|max:16',
                'userName'  => 'require',
            ];
            $msg = [
                'nickName.require'  =>'用户名必填',
                'nickName.unique'  =>'用户名已存在',
                'nickName.min'  =>'用户名长度必须大于6',
                'nickName.max'  =>'用户名长度不得大于16',
                'userName.require'  =>'用户真实姓名必须',
            ];
            $validate = new Validate($rule,$msg);
            $result   = $validate->check($data);
            if(!$result){
                $err_msg = $validate->getError();
                $resData = [
                    'code'=>2,
                    'msg' =>$err_msg
                ];
                return $resData;exit();
            }else{
                //数据处理
                $id = $data['id'];
                unset($data['password']);
                unset($data['phone']);
                unset($data['id']);
                $model = new User;
                $res = $model->where('id','=',$id)->update($data);
                if ($res){
                    $resData = [
                        'code'=>1,
                        'msg'=>'修改成功！'
                    ];
                    return $resData;exit();
                }else{
                    $resData = [
                        'code'=>2,
                        'msg'=>'修改失败，请联系管理员！'
                    ];
                    return $resData;exit();
                }
            }
        }

        //用户名、密码修改，手机号码不修改------Ok
        if($data['nickName'] != '' && $data['password'] != '' && $data['phone'] == ''){
            //数据验证
            $rule =[
                'nickName'  => 'require|unique:user|min:6|max:16',
                'userName'  => 'require',
                'password'  => 'require|min:6|max:10',
            ];
            $msg = [
                'nickName.require'  =>'用户名必填',
                'nickName.unique'  =>'用户名已存在',
                'nickName.min'  =>'用户名长度必须大于6',
                'nickName.max'  =>'用户名长度不得大于16',
                'userName.require'  =>'用户真实姓名必须',
                'password.require'  =>'密码必填',
                'password.min'  =>'密码长度必须大于6位',
                'password.max'  =>'密码长度不大于10位',
            ];
            $validate = new Validate($rule,$msg);
            $result   = $validate->check($data);
            if(!$result){
                $err_msg = $validate->getError();
                $resData = [
                    'code'=>2,
                    'msg' =>$err_msg
                ];
                return $resData;exit();
            }else{
                //数据处理
                $id = $data['id'];
                unset($data['phone']);
                unset($data['id']);
                $salt = $this->getrandstr();
                $data['password'] =  md5($data['password'].$salt);
                $data['salt'] = $salt;
                $model = new User;
                $res = $model->where('id','=',$id)->update($data);
                if ($res){
                    $resData = [
                        'code'=>1,
                        'msg'=>'修改成功！'
                    ];
                    return $resData;exit();
                }else{
                    $resData = [
                        'code'=>2,
                        'msg'=>'修改失败，请联系管理员！'
                    ];
                    return $resData;exit();
                }
            }
        }

        //用户名、手机号码修改，密码不修改-------OK
        if($data['nickName'] != '' && $data['password'] == '' && $data['phone'] != ''){
            //数据验证
            $rule =[
                'nickName'  => 'require|unique:user|min:6|max:16',
                'userName'  => 'require',
                'phone'     =>  'require|unique:user|regex:/^[1][3,4,5,7,8][0-9]{9}$/',
            ];
            $msg = [
                'nickName.require'  =>'用户名必填',
                'nickName.unique'  =>'用户名已存在',
                'nickName.min'  =>'用户名长度必须大于6',
                'nickName.max'  =>'用户名长度不得大于16',
                'userName.require'  =>'用户真实姓名必须',
                'phone.require'  =>'手机号码必填',
                'phone.unique'  =>'手机号码已存在',
                'phone.regex'  =>'手机号码格式不正确',
            ];
            $validate = new Validate($rule,$msg);
            $result   = $validate->check($data);
            if(!$result){
                $err_msg = $validate->getError();
                $resData = [
                    'code'=>2,
                    'msg' =>$err_msg
                ];
                return $resData;exit();
            }else{
                $id = $data['id'];
                unset($data['password']);
                unset($data['id']);
                $model = new User;
                $res = $model->where('id','=',$id)->update($data);
                if ($res){
                    $resData = [
                        'code'=>1,
                        'msg'=>'新增成功！'
                    ];
                    return $resData;exit();
                }else{
                    $resData = [
                        'code'=>2,
                        'msg'=>'新增失败，请联系管理员！'
                    ];
                    return $resData;exit();
                }
            }
        }

        //用户名不修改，密码、手机号码修改------OK
        if($data['nickName'] == '' && $data['password'] != '' && $data['phone'] != ''){
            //数据验证
            $rule =[
                'userName'  => 'require',
                'password'  => 'require|min:6|max:10',
                'phone'     =>  'require|unique:user|regex:/^[1][3,4,5,7,8][0-9]{9}$/',
            ];
            $msg = [
                'userName.require'  =>'用户真实姓名必须',
                'password.require'  =>'密码必填',
                'password.min'  =>'密码长度必须大于6位',
                'password.max'  =>'密码长度不大于10位',
                'phone.require'  =>'手机号码必填',
                'phone.unique'  =>'手机号码已存在',
                'phone.regex'  =>'手机号码格式不正确',
            ];
            $validate = new Validate($rule,$msg);
            $result   = $validate->check($data);
            if(!$result){
                $err_msg = $validate->getError();
                $resData = [
                    'code'=>2,
                    'msg' =>$err_msg
                ];
                return $resData;exit();
            }else{
                $id = $data['id'];
                unset($data['nickName']);
                unset($data['id']);
                $salt = $this->getrandstr();
                $data['password'] =  md5($data['password'].$salt);
                $data['salt'] = $salt;
                $model = new User;
                $res = $model->where('id','=',$id)->update($data);
                if ($res){
                    $resData = [
                        'code'=>1,
                        'msg'=>'修改成功！'
                    ];
                    return $resData;exit();
                }else{
                    $resData = [
                        'code'=>2,
                        'msg'=>'修改失败，请联系管理员！'
                    ];
                    return $resData;exit();
                }
            }
        }

        //用户名、手机号码不修改，密码修改------OK
        if($data['nickName'] == '' && $data['password'] != '' && $data['phone'] == ''){
            //数据验证
            $rule =[
                'userName'  => 'require',
                'password'  => 'require|min:6|max:10',
            ];
            $msg = [
                'userName.require'  =>'用户真实姓名必须',
                'password.require'  =>'密码必填',
                'password.min'  =>'密码长度必须大于6位',
                'password.max'  =>'密码长度不大于10位',
            ];
            $validate = new Validate($rule,$msg);
            $result   = $validate->check($data);
            if(!$result){
                $err_msg = $validate->getError();
                $resData = [
                    'code'=>2,
                    'msg' =>$err_msg
                ];
                return $resData;exit();
            }else{
                $id = $data['id'];
                unset($data['id']);
                unset($data['nickName']);
                unset($data['phone']);
                $salt = $this->getrandstr();
                $data['password'] =  md5($data['password'].$salt);
                $data['salt'] = $salt;
                $model = new User;
                $res = $model->where('id','=',$id)->update($data);
                if ($res){
                    $resData = [
                        'code'=>1,
                        'msg'=>'修改成功！'
                    ];
                    return $resData;exit();
                }else{
                    $resData = [
                        'code'=>2,
                        'msg'=>'修改失败，请联系管理员！'
                    ];
                    return $resData;exit();
                }
            }
        }

        //用户名、密码不修改，手机号码修改-------OK
        if($data['nickName'] == '' && $data['password'] == '' && $data['phone'] != ''){
            //数据验证
            $rule =[
                'userName'  => 'require',
                'phone'     =>  'require|unique:user|regex:/^[1][3,4,5,7,8][0-9]{9}$/',
            ];
            $msg = [
                'userName.require'  =>'用户真实姓名必须',
                'phone.require'  =>'手机号码必填',
                'phone.unique'  =>'手机号码已存在',
                'phone.regex'  =>'手机号码格式不正确',
            ];
            $validate = new Validate($rule,$msg);
            $result   = $validate->check($data);
            if(!$result){
                $err_msg = $validate->getError();
                $resData = [
                    'code'=>2,
                    'msg' =>$err_msg
                ];
                return $resData;exit();
            }else{
                $id = $data['id'];
                unset($data['id']);
                unset($data['nickName']);
                unset($data['password']);
                $model = new User;
                $res = $model->where('id','=',$id)->update($data);
                if ($res){
                    $resData = [
                        'code'=>1,
                        'msg'=>'修改成功！'
                    ];
                    return $resData;exit();
                }else{
                    $resData = [
                        'code'=>2,
                        'msg'=>'修改失败，请联系管理员！'
                    ];
                    return $resData;exit();
                }
            }
        }

    }

    /**用户的启用禁用
     * @param $id
     * @param $status
     * @return array
     */
    public function userStatus($id,$status){
        $model = new User;
        if($status == 1){
            $updData = [
                'status'=>2
            ];
            $res = $model->where('id','=',$id)->update($updData);
            if($res){
                $data = [
                    'code'=>1,
                    'msg'=>'禁用成功！'
                ];
                return $data;exit;
            }else{
                $data = [
                    'code'=>2,
                    'msg'=>'禁用失败，请联系管理员！'
                ];
                return $data;exit;
            }
        }else{
            $updData = [
                'status'=>1
            ];
            $res = $model->where('id','=',$id)->update($updData);
            if($res){
                $data = [
                    'code'=>1,
                    'msg'=>'启用成功！'
                ];
                return $data;exit;
            }else{
                $data = [
                    'code'=>2,
                    'msg'=>'启用失败，请联系管理员！'
                ];
                return $data;exit;
            }
        }
    }

    /**管理员伪删除
     * @param $id
     * @return array
     */
    public function userDel($id){
        $model = new User;
        $data =[
            'status'=>3,
        ];
        $res2 = $model->where('id','=',$id)->update($data);
        $res1 = $model::destroy($id);
        if($res1 &&  $res2){

            $resData = [
                'code'=>1,
                'msg'=>'删除成功！'
            ];
            return $resData;
        }else{
            $resData = [
                'code'=>2,
                'msg'=>'网络繁忙，请稍后再试！'
            ];
            return $resData;
        }
    }


/********************************************数据处理函数************************************************************/

    /**登录成功之后更新盐与密码
     * @param $id
     * @param $password
     * @return bool
     */
    public function saltUpd($id,$password){
        $newSalt = $this->getrandstr();
        $newPassword = md5($password.$newSalt);
        $model = new User;
        $res = $model->where('id','=',$id)->update(['password'=>$newPassword,'salt'=>$newSalt]);
        if($res){
            return true;
        }else{
            return false;
        }
    }

    //数据新增，修改（密码修改）数据验证
    public function data_check($data){
        //数据验证
        $rule =[
            'nickName'  => 'require|unique:user|min:6|max:16',
            'userName'  => 'require',
            'password'  => 'require|min:6|max:10',
            'phone'     => 'require|unique:user|regex:/^[1][3,4,5,7,8][0-9]{9}$/',
        ];
        $msg = [
            'nickName.require'  =>'用户名必填',
            'nickName.unique'  =>'用户名已存在',
            'nickName.min'  =>'用户名长度必须大于6',
            'nickName.max'  =>'用户名长度不得大于16',
            'userName.require'  =>'用户真实姓名必须',
            'password.require'  =>'密码必填',
            'password.min'  =>'密码长度必须大于6位',
            'password.max'  =>'密码长度不大于10位',
            'phone.require'  =>'手机号码必填',
            'phone.unique'  =>'手机号码已存在',
            'phone.regex'  =>'手机号码格式不正确',
        ];
        $validate = new Validate($rule,$msg);
        $result   = $validate->check($data);
        if(!$result){
            $err_msg = $validate->getError();
            $resData = [
                'code'=>2,
                'msg' =>$err_msg
            ];
            return $resData;exit();
        }else{
            $resData = [
                'code'=>1,
                'msg' =>'数据验证通过！'
            ];
            return $resData;exit();
        }
    }

    //ID生成器
    public function createID(){
        $chars = md5(uniqid(mt_rand(), true));
        $uuid  = substr($chars,0,8) . '-';
        $uuid .= substr($chars,8,4) . '-';
        $uuid .= substr($chars,12,4) . '-';
        $uuid .= substr($chars,16,4) . '-';
        $uuid .= substr($chars,20,12);

        return $uuid;
    }

    //随机盐
    public function getrandstr(){
        $str='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890';
        $randStr = str_shuffle($str);//打乱字符串
        $rands= substr($randStr,0,6);//substr(string,start,length);返回字符串的一部分
        return $rands;
    }



}
































