<?php
namespace  app\admin\model;
use think\Model;
use think\Request;
use think\Db;
use traits\model\SoftDelete;
use think\Validate;
Class Member extends Model{
        //设置数据表(不含表前缀)
        protected $name = 'member';
        protected $auto = ['create_time','update_time'];
        use SoftDelete;
        protected $deleteTime = 'delete_time';

    /**新增会员
     * @param $data
     * @return array
     */
    public function memberAdd($data){
        $result   = $this->data_check($data);
        if($result['code'] == 2){
            $resData = [
                'code'=>2,
                'msg'=>$result['msg']
            ];
            return $resData;exit();
        }

        $salt = $this->getrandstr();
        $data['password'] =  md5($data['password'].$salt);
        $data['salt'] = $salt;
        $model = new Member;
        if ($model->save($data)){
            $resData = [
                'code'=>1,
                'msg'=>'新增成功！'
           ];
           return $resData;exit();
        }else{
            $resData = [
                'code'=>2,
                'msg'=>'新增失败，请联系管理员！'
            ];
            return $resData;exit();
        }
    }

    /**会员信息修改
     * @param $data
     * @return array
     */
    public function memberUpd($data){
        return view();
    }

    /**用户的启用禁用
     * @param $id
     * @param $status
     * @return array
     */
    public function memberStatus($id,$status){
        $model = new member;
        if ($status == 1){
            $res = $model->where('_id','=',$id)->update(['status'=> 0]);
        }else if($status == 0){
            $res = $model->where('_id','=',$id)->update(['status'=> 1 ]);
        }
        if($res){
            $resData = [
                'code'=>1,
                'msg'=>'切换成功！'
            ];
            return $resData;exit();
        }else{
            $resData = [
                'code'=>2,
                'msg'=>'切换失败，请联系管理员！'
            ];
            return $resData;exit();
        }
    }

    /**会员删除
     * @param $id
     * @return array
     */
    public function memberDel($id){
        $model = new member;
        $res = $model->where('_id','=',$id)->delete();
        if ($res){
            $resData = [
                'code'=>1,
                'msg'=>'删除成功！'
            ];
            return $resData;exit();
        }else{
            $resData = [
                'code'=>2,
                'msg'=>'删除失败，请联系管理员！'
            ];
            return $resData;exit();
        }
    }

    /**登录成功之后更新盐与密码
     * @param $id
     * @param $password
     * @return bool
     */
    public function saltUpd($id,$password){
        $newSalt = $this->getrandstr();
        $newPassword = md5($password.$newSalt);
        $model = new member;
        $res = $model->where('_id','=',$id)->update(['password'=>$newPassword,'salt'=>$newSalt]);
        if($res){
            return true;
        }else{
            return false;
        }
    }

/********************************************数据处理函数************************************************************/
    //数据新增，修改（密码修改）数据验证
    public function data_check($data){
        //数据验证
        $rule =[
            'nickName'  => 'require|unique:member|min:6|max:16',
            'userName'  => 'require',
            'password'  => 'require|min:6|max:10',
            'phone'     =>  'require|unique:member|regex:/^[1][3,4,5,7,8][0-9]{9}$/',
//            'hospital'  =>  'require',
        ];
        $msg = [
            'nickName.require'  =>'用户名必填',
            'nickName.unique'  =>'用户名已存在',
            'nickName.min'  =>'用户名长度必须大于6',
            'nickName.max'  =>'用户名长度不得大于16',
            'userName.require'  =>'用户真实姓名必须',
            'password.require'  =>'密码必填',
            'password.min'  =>'密码长度必须大于6位',
            'password.max'  =>'密码长度不大于10位',
            'phone.require'  =>'手机号码必填',
            'phone.unique'  =>'手机号码已存在',
            'phone.regex'  =>'手机号码格式不正确',
//            'hospital.require'  =>'医院必选',
        ];
        $validate = new Validate($rule,$msg);
        $result   = $validate->check($data);
        if(!$result){
            $err_msg = $validate->getError();
            $resData = [
                'code'=>2,
                'msg' =>$err_msg
            ];
            return $resData;exit();
        }else{
            $resData = [
                'code'=>1,
                'msg' =>'数据验证通过！'
            ];
            return $resData;exit();
        }
    }


    //随机盐
    public function getrandstr(){
        $str='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890';
        $randStr = str_shuffle($str);//打乱字符串
        $rands= substr($randStr,0,6);//substr(string,start,length);返回字符串的一部分
        return $rands;
    }


}










