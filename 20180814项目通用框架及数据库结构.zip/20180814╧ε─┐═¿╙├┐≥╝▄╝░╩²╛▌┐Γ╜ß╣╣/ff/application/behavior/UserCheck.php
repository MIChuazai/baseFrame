<?php
/**
 * Created by PhpStorm.
 * Creator: 华仔
 * Date: 2018/8/14
 * Time: 9:22
 */
namespace app\admin\behavior;
use think\Controller;

class UserCheck extends Controller{
    use \traits\controller\Jump;//引入jump类
    //绑定CheckAuth标签，检测session判断用户是否登录
    public function run(&$userInfo){
        $userInfo = session('userInfo');
        if(!$userInfo){
            return $this->redirect('login/login');
        }
    }

}


















