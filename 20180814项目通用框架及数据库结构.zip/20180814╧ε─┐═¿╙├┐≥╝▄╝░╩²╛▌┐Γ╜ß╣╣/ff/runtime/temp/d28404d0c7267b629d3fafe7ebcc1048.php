<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:55:"E:\ff\public/../application/admin\view\login\login.html";i:1534218823;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>小路*管理后台</title>
<link rel="stylesheet" type="text/css" href="/static/admin/login/css/style.css" />
<link rel="stylesheet" type="text/css" href="/static/admin/login/css/body.css"/>
</head>
<body>
<div class="container">
	<section id="content">
		<form id="dataForm" >
			<h1>管理员登录</h1>
			<div>
				<input type="text" placeholder="用户名:" required="" name="nickName" id="username" />
			</div>
			<div>
				<input type="password" placeholder="密码:" required="" name="password" id="password" />
			</div>
			 <div class="">
				<span class="help-block u-errormessage" id="js-server-helpinfo">&nbsp;</span>
			 </div>
			<div style="text-align: center">
				<!--<input type="submit" value="登录" class="btn btn-primary" id="js-btn-login"/>-->
				<button type="button"  class="btn btn-primary radius login" id="js-btn-login" onclick="userLogin()">登录</button>
			</div>
		</form><!-- form -->
	</section><!-- content -->
</div>
<!-- container -->


<br><br><br><br>
</body>
<script type="text/javascript" src="/static/admin/lib/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="/static/admin/lib/layer/2.4/layer.js"></script>
<script type="text/javascript">
	function pageJump(){
        location.href = "<?php echo url('index/index'); ?>";
	}

	function userLogin(){
	    var _nickName = $('#username').val();
	    var _password = $('#password').val();
	    var _data = $('#dataForm').serialize();
	    if(!_nickName || !_password){
	        layer.msg('用户名 密码不能为空1',{icon: 5,time:1000});
	        return false;
		}else{
			$.ajax({
				 url: "<?php echo url('login/checkLogin'); ?>",
				 type: 'POST',
				 dataType: 'json',
				 data:{'data':_data}, //传递的参数
				 success: function(json){
					 if(json.code==2){
						 layer.msg(json.msg,{icon: 5,time:1000});
						 return false;
					 }else if(json.code==1){
						 layer.msg(json.msg,{icon:1,time:1000});
						 setTimeout('pageJump()',1000);
						 return true;
					 }
				 }
			 });
		}

	}
</script>
</html>