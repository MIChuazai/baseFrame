<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:59:"E:\ff\public/../application/admin\view\user\manger_lst.html";i:1534225967;}*/ ?>
<!DOCTYPE HTML>
<html>

<head>
    <meta charset="utf-8">
    <meta name="renderer" content="webkit|ie-comp|ie-stand">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <link rel="Bookmark" href="/favicon.ico">
    <link rel="Shortcut Icon" href="/favicon.ico" />
    <link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui/css/H-ui.min.css" />
    <link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui.admin/css/H-ui.admin.css" />
    <link rel="stylesheet" type="text/css" href="/static/admin/lib/Hui-iconfont/1.0.8/iconfont.css" />
    <link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui.admin/skin/default/skin.css" id="skin" />
    <title>管理员列表</title>
    <style type="text/css">
        .containers{
            padding: 30px;
        }
        .btn_more {
            background: #3caef6!important;
            border: 1px solid #3caef6!important;
            color: white;
        }

        .refreshs {
            display: inline-block;
            border: 1px solid #d5d5d5;
            padding: 4px 8px;
            margin-top: 30px;
            margin-bottom: 30px;
        }

        .refreshs input {
            border: none;
        }

        .refreshs i {
            cursor: pointer;
        }
    </style>
</head>

<body>
<div id="" class="containers">
    <header>
        <a href="<?php echo url('user/manger_add'); ?>"><button class="btn btn-success radius patient-data"><i class="Hui-iconfont Hui-iconfont-add "></i>新增</button></a>
    </header>

    <main>
        <table class="table table-border  table-hover table-bg table-sort">
            <thead>
            <tr class="text-c">
                <th width="100">序号</th>
                <th width="200">用户名</th>
                <th width="200">真实姓名</th>
                <th width="150">性别</th>
                <th width="150">电话</th>
                <th width="150">状态</th>
                <th width="">操作</th>
            </tr>
            </thead>
            <tbody>
            <?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?>
                <tr class="text-c">
                    <td><?php echo $key+1; ?></td>
                    <td><?php echo $val['nickName']; ?></td>
                    <td><?php echo $val['userName']; ?></td>
                    <td><?php echo $val['sex']==1?'男':'女'; ?></td>
                    <td><?php echo $val['phone']; ?></td>
                    <td><span class="<?php echo $val['status']==1?'label label-success radius':'label label-default radius'; ?>" id="<?php echo $val['id']; ?>"><?php echo $val['status']==1?'已启用':'已禁用'; ?></span></td>
                    <td>
                        <button type="button" class="btn btn_more radius" tag="<?php echo $val['id']; ?>" onclick="data_upd(this)">编辑</button>
                        <button type="button" class="<?php echo $val['status']==1?'btn btn-warning radius':'btn btn-success radius'; ?>" userID="<?php echo $val['id']; ?>" status="<?php echo $val['status']; ?>" onclick="user_change(this)"><?php echo $val['status']==1?'禁用':'启用'; ?></button>
                        <button type="button" class="btn btn-danger radius" tag="<?php echo $val['id']; ?>"  onclick="user_del(this)">删除</button>
                    </td>
                </tr>
             <?php endforeach; endif; else: echo "" ;endif; ?>
            </tbody>
        </table>
    </main>
</div>

<!--_footer 作为公共模版分离出去-->
<script type="text/javascript" src="/static/admin/lib/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="/static/admin/lib/layer/2.4/layer.js"></script>
<script type="text/javascript" src="/static/admin/static/h-ui/js/H-ui.min.js"></script>
<script type="text/javascript" src="/static/admin/static/h-ui.admin/js/H-ui.admin.js"></script>
<!--/_footer 作为公共模版分离出去-->
<script type="text/javascript" src="/static/admin/lib/datatables/1.10.0/jquery.dataTables.min.js"></script>

<!--请在下方写此页面业务相关的脚本-->
<script type="text/javascript">
    $(function() {
        $('.table-sort').dataTable({
//            "aaSorting": [
//                [1, "desc"]
//            ], //默认第几个排序
            "bLengthChange": false,

            "aoColumnDefs": [
                //{"bVisible": false, "aTargets": [ 3 ]} //控制列的隐藏显示
                {
                    "orderable": false,
//							"aTargets": [0, 8, 9]
                }
            ]
        });
    });

    //数据编辑
    function data_upd(obj){
        var id = $(obj).attr('tag');
        self.location.href = "<?php echo url('user/manger_upd'); ?>?id="+id;
    }

    //管理员删除
    function user_del(obj){
        var id = $(obj).attr('tag');
        $.ajax({
            url: "<?php echo url('user/user_del'); ?>",
            type: 'POST',
            dataType: 'json',
            data:{'id':id}, //传递的参数
            success: function(json){
                if(json.code==2){
                    layer.msg(json.msg,{icon: 5,time:1000});
                    return false;
                }else if(json.code==1){
                    $(obj).parent().parent().remove();
                    layer.msg(json.msg,{icon:1,time:1000});
                    return true;
                }
            }
        });
    }

    //管理员的启用禁用
    function user_change(obj){
        var id = $(obj).attr('userID');
        var status = $(obj).attr('status');
        $.ajax({
            url: "<?php echo url('user/userStatus'); ?>",
            type: 'POST',
            dataType: 'json',
            data:{'id':id,'status':status}, //传递的参数
            success: function(json){
                if(json.code==2){
                    if(status == 1){
                        layer.msg('禁用失败，请联系管理员!',{icon: 5,time:1000});
                    }else if(status == 0){
                        layer.msg('启用失败，请联系管理员!',{icon: 5,time:1000});
                    }
                    return false;
                }else if(json.code==1){
                    if(status == 1){
                        $("#"+id).attr('class','label label-default radius');
                        $("#"+id).html('已禁用');
                        $(obj).attr('class','btn btn-success radius');
                        $(obj).html('启用');
                        $(obj).attr('status',0);
                        layer.msg('禁用成功!',{icon:1,time:1000});
                    }else if(status == 0){
                        $("#"+id).attr('class','label label-success radius');
                        $("#"+id).html('已启用');
                        $(obj).attr('class','btn btn-warning radius');
                        $(obj).html('禁用');
                        $(obj).attr('status',1);
                        layer.msg('启用成功!',{icon: 1,time:1000});
                    }
                    return true;
                }
            }
        });
    }

</script>
</body>

</html>