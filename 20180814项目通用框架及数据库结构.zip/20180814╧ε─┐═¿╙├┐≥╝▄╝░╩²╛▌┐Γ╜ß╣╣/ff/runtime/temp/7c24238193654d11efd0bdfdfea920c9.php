<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:59:"E:\ff\public/../application/admin\view\user\manger_upd.html";i:1534228724;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
<meta http-equiv="Cache-Control" content="no-siteapp" />
<LINK rel="Bookmark" href="/favicon.ico" >
<LINK rel="Shortcut Icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui/css/H-ui.min.css" />
<link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui.admin/css/H-ui.admin.css" />
<link rel="stylesheet" type="text/css" href="/static/admin/lib/Hui-iconfont/1.0.8/iconfont.css" />
<link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui.admin/skin/default/skin.css" id="skin" />
<!--/meta 作为公共模版分离出去-->

<title>添加管理员</title>
</head>
<body>
<article class="page-container">
	<form class="form form-horizontal" id="form-admin-add" method="post" >
	<div class="row cl">
		<label class="form-label col-xs-4 col-sm-3">用户名：</label>
		<div class="formControls col-xs-8 col-sm-9">
			<input type="text" class="input-text"  placeholder="原用户名为：<?php echo $data['nickName']; ?>，不修改请置空，用户名长度6-10位" autocomplete="off" id="nickName" name="nickName" value="" onblur="data_deal(this)">
		</div>
	</div>
	<div class="row cl">
		<label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>真实姓名：</label>
		<div class="formControls col-xs-8 col-sm-9">
			<input type="text" class="input-text"  placeholder="" autocomplete="off" id="userName" name="userName" value="<?php echo $data['userName']; ?>">
		</div>
	</div>
	<div class="row cl">
		<label class="form-label col-xs-4 col-sm-3">密码：</label>
		<div class="formControls col-xs-8 col-sm-9">
			<input type="password" class="input-text" autocomplete="off"  placeholder="密码不修改请置空，密码长度6-10位" id="password" name="password">
		</div>
	</div>
	<div class="row cl">
		<label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>性别：</label>
		<div class="formControls col-xs-8 col-sm-9 skin-minimal">
			<div class="radio-box">
				<input name="sex" type="radio" id="sex-1" class="sex" <?php echo $data['sex']=='1'?'checked':''; ?> value="1">
				<label for="sex-1">男</label>
			</div>
			<div class="radio-box">
				<input type="radio" id="sex-2" class="sex" name="sex" <?php echo $data['sex']=='2'?'checked':''; ?> value="2">
				<label for="sex-2">女</label>
			</div>
		</div>
	</div>
	<div class="row cl">
		<label class="form-label col-xs-4 col-sm-3">联系电话：</label>
		<div class="formControls col-xs-8 col-sm-9">
			<input type="text" class="input-text"  placeholder="原号码：<?php echo $data['phone']; ?>，不修改请置空"  autocomplete="off" id="phone" name="phone" value="" onblur="data_deal(this)">
		</div>
	</div>
	<div class="row cl">
			<label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>是否启用：</label>
			<div class="formControls col-xs-8 col-sm-9 skin-minimal">
				<div class="radio-box">
					<input name="status" type="radio" class="status" id="status-1" <?php echo $data['status']==1?'checked':''; ?> value=1>
					<label for="status-1">启用</label>
				</div>
				<div class="radio-box">
					<input type="radio" id="status-2" class="status" name="status" value=2 <?php echo $data['status']==2?'checked':''; ?>>
					<label for="status-2">禁用</label>
				</div>
			</div>
		</div>
	<div class="row cl">
		<div class="col-xs-8 col-sm-9 col-xs-offset-4 col-sm-offset-3">
		<button type="button"  class="btn btn-success radius"  onclick="user_upd()">提交</button>
		<a href="<?php echo url('user/manger_lst'); ?>"><button type="button"  class="btn btn-danger radius">取消</button></a>
		</div>
	</div>
	</form>
</article>

<!--_footer 作为公共模版分离出去--> 
<script type="text/javascript" src="http://lib.h-ui.net/jquery/1.9.1/jquery.min.js"></script> 
<script type="text/javascript" src="http://lib.h-ui.net/layer/2.1/layer.js"></script> 
<script type="text/javascript" src="http://lib.h-ui.net/icheck/jquery.icheck.min.js"></script> 
<script type="text/javascript" src="http://lib.h-ui.net/jquery.validation/1.14.0/jquery.validate.min.js"></script> 
<script type="text/javascript" src="http://lib.h-ui.net/jquery.validation/1.14.0/validate-methods.js"></script> 
<script type="text/javascript" src="http://lib.h-ui.net/jquery.validation/1.14.0/messages_zh.min.js"></script> 
<script type="text/javascript" src="/static/admin/static/h-ui/js/H-ui.js"></script>
<script type="text/javascript" src="/static/admin/static/h-ui.admin/js/H-ui.admin.js"></script>
<!--/_footer /作为公共模版分离出去--> 

<!--请在下方写此页面业务相关的脚本--> 
<script type="text/javascript">
$(function(){
	$('.skin-minimal input').iCheck({
		checkboxClass: 'icheckbox-blue',
		radioClass: 'iradio-blue',
		increaseArea: '20%'
	});
	$("#form-admin-add").validate({
		rules:{
			userName:{
				required:true
			},
        },
        messages:{
            userName:{
                required:"请输入用户的真实姓名！"
            },
		}

    });

});

function jump_page(){
    location.href = "<?php echo url('user/mangerLst'); ?>";
}

//数据修改
var id = "<?php echo \think\Request::instance()->get('id'); ?>";
function user_upd() {
   if($("#form-admin-add").valid()){
       $.ajax({
           url: "<?php echo url('user/mangerUpd'); ?>",
           type: 'POST',
           dataType: 'json',
           data: {'id':id,'userData': $("#form-admin-add").serialize()}, //传递的参数
           success: function (json) {
               if (json.code == 2) {
                   layer.msg(json.msg, {icon: 5, time: 3000});
                   return false;
               } else if (json.code == 1) {
                   layer.msg(json.msg, {icon: 1, time: 10000});
                   setTimeout('jump_page()',1000);
                   return true;
               }
           }
       });
   }
}


</script> 
<!--/请在上方写此页面业务相关的脚本-->
</body>
</html>