<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:59:"E:\ff\public/../application/admin\view\user\manger_add.html";i:1534210643;}*/ ?>

<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
<meta http-equiv="Cache-Control" content="no-siteapp" />
<LINK rel="Bookmark" href="/favicon.ico" >
<LINK rel="Shortcut Icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui/css/H-ui.min.css" />
<link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui.admin/css/H-ui.admin.css" />
<link rel="stylesheet" type="text/css" href="/static/admin/lib/Hui-iconfont/1.0.8/iconfont.css" />
<link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui.admin/skin/default/skin.css" id="skin" />
<!--/meta 作为公共模版分离出去-->

<title>添加管理员</title>
</head>
<body>
<article class="page-container">
	<form class="form form-horizontal" id="form-admin-add" method="post">
	<div class="row cl">
		<label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>用户名：</label>
		<div class="formControls col-xs-8 col-sm-9">
			<input type="text" class="input-text"  placeholder="必填，长度6-16位" autocomplete="off" id="nickName" name="nickName" >
		</div>
	</div>
	<div class="row cl">
		<label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>真实姓名：</label>
		<div class="formControls col-xs-8 col-sm-9">
			<input type="text" class="input-text"  placeholder="必填" autocomplete="off" id="userName" name="userName">
		</div>
	</div>
	<div class="row cl">
		<label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>初始密码：</label>
		<div class="formControls col-xs-8 col-sm-9">
			<input type="password" class="input-text" autocomplete="off"  placeholder="必填，长度6-10位" id="password" name="password">
		</div>
	</div>
	<div class="row cl">
		<label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>性别：</label>
		<div class="formControls col-xs-8 col-sm-9 skin-minimal">
			<div class="radio-box">
				<input name="sex" type="radio" id="sex-1" class="sex" checked value=1>
				<label for="sex-1">男</label>
			</div>
			<div class="radio-box">
				<input type="radio" id="sex-2" class="sex" name="sex" value=2>
				<label for="sex-2">女</label>
			</div>
		</div>
	</div>
	<div class="row cl">
		<label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>联系电话：</label>
		<div class="formControls col-xs-8 col-sm-9">
			<input type="text" class="input-text"  placeholder="必填"  autocomplete="off" id="phone" name="phone" >
		</div>
	</div>
	<div class="row cl">
			<label class="form-label col-xs-4 col-sm-3"><span class="c-red">*</span>是否启用：</label>
			<div class="formControls col-xs-8 col-sm-9 skin-minimal">
				<div class="radio-box">
					<input name="status" type="radio" class="status" id="status-1" checked value=1>
					<label for="status-1">启用</label>
				</div>
				<div class="radio-box">
					<input type="radio" id="status-2" class="status" name="status" value=2>
					<label for="status-2">禁用</label>
				</div>
			</div>
		</div>
	<div class="row cl">
		<div class="col-xs-8 col-sm-9 col-xs-offset-4 col-sm-offset-3">
			<input type="button"  class="btn btn-success radius" value="提交" onclick="manger_add()"/>
			<a href="<?php echo url('user/manger_lst'); ?>"><input type="button"  class="btn btn-danger radius" value="取消" /></a>
		</div>
	</div>
	</form>
</article>

<!--_footer 作为公共模版分离出去--> 
<script type="text/javascript" src="http://lib.h-ui.net/jquery/1.9.1/jquery.min.js"></script> 
<script type="text/javascript" src="http://lib.h-ui.net/layer/2.1/layer.js"></script> 
<script type="text/javascript" src="http://lib.h-ui.net/icheck/jquery.icheck.min.js"></script> 
<script type="text/javascript" src="http://lib.h-ui.net/jquery.validation/1.14.0/jquery.validate.min.js"></script> 
<script type="text/javascript" src="http://lib.h-ui.net/jquery.validation/1.14.0/validate-methods.js"></script> 
<script type="text/javascript" src="http://lib.h-ui.net/jquery.validation/1.14.0/messages_zh.min.js"></script> 
<script type="text/javascript" src="/static/admin/static/h-ui/js/H-ui.js"></script>
<script type="text/javascript" src="/static/admin/static/h-ui.admin/js/H-ui.admin.js"></script>
<!--/_footer /作为公共模版分离出去--> 

<!--请在下方写此页面业务相关的脚本--> 
<script type="text/javascript">
$(function(){
	$('.skin-minimal input').iCheck({
		checkboxClass: 'icheckbox-blue',
		radioClass: 'iradio-blue',
		increaseArea: '20%'
	});
	$("#form-admin-add").validate({
		rules:{
            nickName:{
                required:true,
                minlength:6,
                maxlength:16,
                remote:{                                          //验证用户名是否存在
                    type:"POST",
                    url:"<?php echo url('user/data_unique'); ?>",
                    dataType: "json",
                    data:{val:function(){return $("#nickName").val();},name:function(){return 'nickName'}}
                }
            },
			userName:{
				required:true
			},
			password:{
				required:true,
                minlength:6,
                maxlength:10
			},
			phone:{
				required:true,
                isMobile:true,
				remote:{
					type:"POST",
						url:"<?php echo url('user/data_unique'); ?>",
						dataType: "json",
						data:{val:function(){return $("#phone").val();},name:function(){return 'phone'}}
				}
			},

        },
        messages:{
            nickName:{
                required:"请输入用户名！",
                minlength:"用户名不得少于6个长度！",
                maxlength:"用户名不得多于16个长度！"
            },
            userName:{
                required:"请输入用户的真实姓名！"
            },
            password:{
                required:"请输入用户密码！",
                minlength:"密码长度不得小于6！",
                maxlength:"密码长度不得大于10！"
            },
            phone:{
                required:"请输入用户的联系电话！",
                isMobile:"输入的号码格式不正确！"
            },
		}

    });

});

function jump_page(){
    location.href = "<?php echo url('user/mangerLst'); ?>";

}

//数据新增
function manger_add() {
    var _data = $("#form-admin-add").serialize();
    console.log(_data);
   if($("#form-admin-add").valid()){
       $.ajax({
           url: "<?php echo url('user/mangerAdd'); ?>",
           type: 'POST',
           dataType: 'json',
           data: {'userData': $("#form-admin-add").serialize()}, //传递的参数
           success: function (json) {
               if (json.code == 2) {
                   layer.msg(json.msg, {icon: 5, time: 3000});
                   return false;
               } else if (json.code == 1) {
                   layer.msg(json.msg, {icon: 1, time: 10000});
				   setTimeout('jump_page()',1000);
				   return true;
               }
           }
       });
   }
}

</script> 
<!--/请在上方写此页面业务相关的脚本-->
</body>
</html>