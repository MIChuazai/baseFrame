<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:55:"E:\ff\public/../application/admin\view\index\index.html";i:1534224541;}*/ ?>
﻿<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="Bookmark" href="/favicon.ico" >
<link rel="Shortcut Icon" href="/favicon.ico" />
<!--[if lt IE 9]>
<script type="text/javascript" src="/static/admin/lib/html5shiv.js"></script>
<script type="text/javascript" src="/static/admin/lib/respond.min.js"></script>
<![endif]-->
<link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui/css/H-ui.min.css" />
<link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui.admin/css/H-ui.admin.css" />
<link rel="stylesheet" type="text/css" href="/static/admin/lib/Hui-iconfont/1.0.8/iconfont.css" />
<link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui.admin/skin/default/skin.css" id="skin" />
<link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui.admin/css/style.css" />
<!--[if IE 6]>
<script type="text/javascript" src="/static/admin/lib/DD_belatedPNG_0.0.8a-min.js" ></script>
<script>DD_belatedPNG.fix('*');</script>
<![endif]-->
<title>小路*后台管理系统</title>
</head>
<body>
<header class="navbar-wrapper">
	<div class="navbar navbar-fixed-top">
		<div class="container-fluid cl"> <a class="logo navbar-logo f-l mr-10 hidden-xs" href="/aboutHui.shtml">小路*后台管理系统</a>
			<span class="logo navbar-slogan f-l mr-10 hidden-xs">V1.0</span>
			<a aria-hidden="false" class="nav-toggle Hui-iconfont visible-xs" href="javascript:;">&#xe667;</a>
			<nav class="nav navbar-nav">
				<ul class="cl">
				</li>
			</ul>
		</nav>
		<nav id="Hui-userbar" class="nav navbar-nav navbar-userbar hidden-xs">
			<ul class="cl">
				<li>用户名:</li>
				<li class="dropDown dropDown_hover">
					<a href="#" class="dropDown_A"><?php echo \think\Session::get('userInfo.userName'); ?></a>
					<!--<ul class="dropDown-menu menu radius box-shadow">-->
						<!--&lt;!&ndash;<li><a href="javascript:;" onClick="myselfinfo()">个人信息</a></li>&ndash;&gt;-->
						<!--&lt;!&ndash;<li><a href="#">切换账户</a></li>&ndash;&gt;-->
						<!--<li><a href="#">退出</a></li>-->
					<!--</ul>-->
				</li>
				<li><a href="<?php echo url('login/loginOut'); ?>"><button type="button" class="btn btn-success raduice" onclick="loginOut()">退出</button></a></li>
			</ul>
		</nav>
	</div>
</div>
</header>
<aside class="Hui-aside">
	<div class="menu_dropdown bk_2">
		<!--会员管理-->
		<dl id="menu-member">
			<dt><i class="Hui-iconfont">&#xe60d;</i> 用户管理<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>
			<dd>
				<ul>
					<li><a data-href="<?php echo url('user/mangerLst'); ?>" data-title="管理员列表" href="javascript:;">管理员列表</a></li>
					<!--<li><a data-href="<?php echo url('user/memberLst'); ?>" data-title="会员列表" href="javascript:;">会员列表</a></li>-->
				</ul>
			</dd>
		</dl>

		<!--审批管理-->
		<dl id="menu-product">
			<dt><i class="Hui-iconfont">&#xe620;</i> 审核中心<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>
			<dd>
				<ul>
					<li><a data-href="<?php echo url('check/prePass'); ?>" data-title="待审核列表" href="javascript:void(0)">待审核列表</a></li>
					<li><a data-href="<?php echo url('check/endPass'); ?>" data-title="已审核列表" href="javascript:void(0)">已审核列表</a></li>
				</ul>
			</dd>
		</dl>

		<!--&lt;!&ndash;费率调控&ndash;&gt;-->
		<!--<dl id="menu-product">-->
			<!--<dt><i class="Hui-iconfont">&#xe620;</i> 费率调控<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>-->
			<!--<dd>-->
				<!--<ul>-->
					<!--<li><a data-href="<?php echo url('charge/chargeRate'); ?>" data-title="费率列表" href="javascript:void(0)">费率列表</a></li>-->
				<!--</ul>-->
			<!--</dd>-->
		<!--</dl>-->

		<!--&lt;!&ndash;资讯管理&ndash;&gt;-->
		<!--<dl id="menu-article">-->
			<!--<dt><i class="Hui-iconfont">&#xe616;</i> 资讯管理<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>-->
			<!--<dd>-->
				<!--<ul>-->
					<!--<li><a data-href="<?php echo url('information/msgSend'); ?>" data-title="消息推送" href="javascript:void(0)">消息推送</a></li>-->
				<!--</ul>-->
			<!--</dd>-->
		<!--</dl>-->

		<!--&lt;!&ndash;系统统计&ndash;&gt;-->
		<!--<dl id="menu-tongji">-->
			<!--<dt><i class="Hui-iconfont">&#xe61a;</i> 统计中心<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>-->
			<!--<dd>-->
				<!--<ul>-->
					<!--<li><a data-href="<?php echo url('count/rechargeLst'); ?>" data-title="充值记录" href="javascript:void(0)">充值记录</a></li>-->
					<!--<li><a data-href="<?php echo url('count/dataCount'); ?>" data-title="数据汇总" href="javascript:void(0)">数据汇总</a></li>-->
				<!--</ul>-->
			<!--</dd>-->
		<!--</dl>-->

		<!--资讯管理-->
		<!--<dl id="menu-article">-->
			<!--<dt><i class="Hui-iconfont">&#xe616;</i> 资讯管理<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>-->
			<!--<dd>-->
				<!--<ul>-->
					<!--<li><a data-href="article-list.html" data-title="资讯管理" href="javascript:void(0)">资讯管理</a></li>-->
			<!--</ul>-->
		<!--</dd>-->
	<!--</dl>-->

		<!--图片管理-->
		<!--<dl id="menu-picture">-->
			<!--<dt><i class="Hui-iconfont">&#xe613;</i> 图片管理<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>-->
			<!--<dd>-->
				<!--<ul>-->
					<!--<li><a data-href="picture-list.html" data-title="图片管理" href="javascript:void(0)">图片管理</a></li>-->
			<!--</ul>-->
		<!--</dd>-->
	<!--</dl>-->

		<!--评论管理-->
		<!--<dl id="menu-comments">-->
			<!--<dt><i class="Hui-iconfont">&#xe622;</i> 评论管理<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>-->
			<!--<dd>-->
				<!--<ul>-->
					<!--<li><a data-href="http://h-ui.duoshuo.com/admin/" data-title="评论列表" href="javascript:;">评论列表</a></li>-->
					<!--<li><a data-href="feedback-list.html" data-title="意见反馈" href="javascript:void(0)">意见反馈</a></li>-->
			<!--</ul>-->
		<!--</dd>-->
	<!--</dl>-->

		<!--管理员管理-->
		<!--<dl id="menu-admin">-->
			<!--<dt><i class="Hui-iconfont">&#xe62d;</i> 管理员管理<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>-->
			<!--<dd>-->
				<!--<ul>-->
					<!--<li><a data-href="admin-role.html" data-title="管理员列表" href="javascript:void(0)">管理员列表</a></li>-->
					<!--&lt;!&ndash;<li><a data-href="admin-permission.html" data-title="权限管理" href="javascript:void(0)">权限管理</a></li>&ndash;&gt;-->
					<!--&lt;!&ndash;<li><a data-href="admin-list.html" data-title="管理员列表" href="javascript:void(0)">管理员列表</a></li>&ndash;&gt;-->
			<!--</ul>-->
		<!--</dd>-->
	<!--</dl>-->
		<!--放款管理-->
		<!--<dl id="menu-tongji">-->
			<!--<dt><i class="Hui-iconfont">&#xe62d;</i> 放款管理<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>-->
			<!--<dd>-->
				<!--<ul>-->
					<!--<li><a data-href="product-category.html" data-title="已放款列表" href="javascript:void(0)">已放款列表</a></li>-->
					<!--<li><a data-href="admin-role.html" data-title="逾期列表" href="javascript:void(0)">逾期列表</a></li>-->
					<!--&lt;!&ndash;<li><a data-href="admin-permission.html" data-title="权限管理" href="javascript:void(0)">权限管理</a></li>&ndash;&gt;-->
					<!--&lt;!&ndash;<li><a data-href="admin-list.html" data-title="管理员列表" href="javascript:void(0)">管理员列表</a></li>&ndash;&gt;-->
				<!--</ul>-->
			<!--</dd>-->
		<!--</dl>-->

		<!--系统管理-->
		<!--<dl id="menu-system">-->
			<!--<dt><i class="Hui-iconfont">&#xe62e;</i> 系统管理<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>-->
			<!--<dd>-->
				<!--<ul>-->
					<!--<li><a data-href="system-base.html" data-title="系统设置" href="javascript:void(0)">系统设置</a></li>-->
					<!--<li><a data-href="system-category.html" data-title="栏目管理" href="javascript:void(0)">栏目管理</a></li>-->
					<!--<li><a data-href="system-data.html" data-title="数据字典" href="javascript:void(0)">数据字典</a></li>-->
					<!--<li><a data-href="system-shielding.html" data-title="屏蔽词" href="javascript:void(0)">屏蔽词</a></li>-->
					<!--<li><a data-href="system-log.html" data-title="系统日志" href="javascript:void(0)">系统日志</a></li>-->
			<!--</ul>-->
		<!--</dd>-->
	<!--</dl>-->
</div>
</aside>
<div class="dislpayArrow hidden-xs"><a class="pngfix" href="javascript:void(0);" onClick="displaynavbar(this)"></a></div>
<section class="Hui-article-box">
	<div id="Hui-tabNav" class="Hui-tabNav hidden-xs">
		<div class="Hui-tabNav-wp">
			<ul id="min_title_list" class="acrossTab cl">
				<li class="active">
					<span title="我的桌面" data-href="welcome.html">我的桌面</span>
					<em></em>
				</li>
		</ul>
	</div>
		<div class="Hui-tabNav-more btn-group"><a id="js-tabNav-prev" class="btn radius btn-default size-S" href="javascript:;"><i class="Hui-iconfont">&#xe6d4;</i></a><a id="js-tabNav-next" class="btn radius btn-default size-S" href="javascript:;"><i class="Hui-iconfont">&#xe6d7;</i></a></div>
</div>
	<div id="iframe_box" class="Hui-article">
		<div class="show_iframe">
			<div style="display:none" class="loading"></div>
			<iframe scrolling="yes" frameborder="0" src="welcome.html"></iframe>
	</div>
</div>
</section>

<div class="contextMenu" id="Huiadminmenu">
	<ul>
		<li id="closethis">关闭当前 </li>
		<li id="closeall">关闭全部 </li>
</ul>
</div>
<!--_footer 作为公共模版分离出去-->
<script type="text/javascript" src="/static/admin/lib/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="/static/admin/lib/layer/2.4/layer.js"></script>
<script type="text/javascript" src="/static/admin/static/h-ui/js/H-ui.min.js"></script>
<script type="text/javascript" src="/static/admin/static/h-ui.admin/js/H-ui.admin.js"></script> <!--/_footer 作为公共模版分离出去-->

<!--请在下方写此页面业务相关的脚本-->
<script type="text/javascript" src="/static/admin/lib/jquery.contextmenu/jquery.contextmenu.r2.js"></script>
<script type="text/javascript">
$(function(){
	/*$("#min_title_list li").contextMenu('Huiadminmenu', {
		bindings: {
			'closethis': function(t) {
				console.log(t);
				if(t.find("i")){
					t.find("i").trigger("click");
				}		
			},
			'closeall': function(t) {
				alert('Trigger was '+t.id+'\nAction was Email');
			},
		}
	});*/
});
	
</script> 


</body>
</html>